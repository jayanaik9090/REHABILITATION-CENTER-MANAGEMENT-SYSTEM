-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2019 at 06:56 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hms`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `hist` (IN `did` INT(11))  NO SQL
select users.fullName as fname,appointment.*  from appointment join users on users.id=appointment.userId where appointment.doctorId=did$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `updationDate`) VALUES
(1, 'admin', 'jaytej90', '22-11-2019 09:03:52 PM');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `doctorSpecialization` varchar(255) DEFAULT NULL,
  `doctorId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `consultancyFees` int(11) DEFAULT NULL,
  `appointmentDate` varchar(255) DEFAULT NULL,
  `appointmentTime` varchar(255) DEFAULT NULL,
  `postingDate` date DEFAULT current_timestamp(),
  `userStatus` int(11) DEFAULT NULL,
  `doctorStatus` int(11) DEFAULT NULL,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `doctorSpecialization`, `doctorId`, `userId`, `consultancyFees`, `appointmentDate`, `appointmentTime`, `postingDate`, `userStatus`, `doctorStatus`, `updationDate`) VALUES
(24, 'Detoxification Program Type 1', 22, 22, 3000, '2019-11-30', '12:00 PM', '2019-11-29', 1, 1, NULL),
(25, 'Detoxification Program Type 1', 22, 22, 3000, '2019-12-13', '12:15 AM', '2019-11-30', 1, 1, NULL),
(26, 'Narcotics meeting', 27, 16, 2000, '2019-12-18', '7:00 AM', '2019-11-30', 1, 1, NULL),
(27, 'Detoxification Program Type 2', 23, 19, 3000, '2019-12-20', '1:00 PM', '2019-11-30', 1, 1, NULL);

--
-- Triggers `appointment`
--
DELIMITER $$
CREATE TRIGGER `trig` AFTER INSERT ON `appointment` FOR EACH ROW BEGIN
DECLARE date1 date;
DECLARE date2 date;
DECLARE id1 int;
set @date1:=(SELECT appointmentDate from appointment ORDER BY id DESC LIMIT 1);
set @date2:=(SELECT PostingDate from appointment ORDER BY id DESC LIMIT 1);
set @id1:= (SELECT id FROM appointment ORDER BY id DESC limit 1);
if @date1<@date2 THEN
 DELETE from appointment WHERE id=@id1;
END if;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `specilization` varchar(255) DEFAULT NULL,
  `doctorName` varchar(255) DEFAULT NULL,
  `address` longtext DEFAULT NULL,
  `docFees` varchar(255) DEFAULT NULL,
  `contactno` bigint(11) DEFAULT NULL,
  `docEmail` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `specilization`, `doctorName`, `address`, `docFees`, `contactno`, `docEmail`, `password`, `creationDate`, `updationDate`) VALUES
(22, 'Detoxification Program Type 1', 'Jagath', 'Bangalore', '3000', 8123456789, 'docjagath@gmail.com', '483566b5834008510356c2b5a71ebebe', '2019-11-29 17:25:23', NULL),
(23, 'Detoxification Program Type 2', 'Thrishul', 'Karkal', '3000', 9123456789, 'docthrishul@gmail.com', '272d4a73da8da09fccd0b0eb2669fc50', '2019-11-29 17:28:50', NULL),
(24, 'Counseling', 'Elsten', 'manglore', '2000', 7894561237, 'docelsten@gmail.com', 'e4dbd5e4d8a701cf0f412d3db6d41d34', '2019-11-29 17:29:34', NULL),
(25, 'Group Therapy', 'Jayraj', 'Moodbidri', '2500', 8123456789, 'docjayraj@gmail.com', 'fa04b7b157796c24aaa3a91fc0873526', '2019-11-29 17:30:59', NULL),
(26, 'Narcotics meeting', 'Nikhil', 'Murdeshwar', '2500', 7899089916, 'docnik@gmai.com', '0f3959de244d09d64b9ef464bc6e4c85', '2019-11-29 17:44:17', NULL),
(27, 'Narcotics meeting', 'Jaya', 'Murdeshwar', '2000', 6362314293, 'docjaya@gmail.com', '4c86e9c13d30475687ddf0a042e85b58', '2019-11-29 17:45:27', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `doctorslog`
--

CREATE TABLE `doctorslog` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT current_timestamp(),
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorslog`
--

INSERT INTO `doctorslog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(64, 16, 'docjagath@gmail.com', 0x3a3a3100000000000000000000000000, '2019-11-25 06:37:53', '25-11-2019 12:12:17 PM', 1),
(65, 16, 'docjagath@gmail.com', 0x3a3a3100000000000000000000000000, '2019-11-29 15:45:06', NULL, 1),
(66, 22, 'docjagath@gmail.com', 0x3a3a3100000000000000000000000000, '2019-11-29 18:28:59', NULL, 1),
(67, 27, 'docjaya@gmail.com', 0x3a3a3100000000000000000000000000, '2019-11-30 01:17:08', '30-11-2019 06:49:47 AM', 1),
(68, 27, 'docjaya@gmail.com', 0x3a3a3100000000000000000000000000, '2019-11-30 05:59:01', '30-11-2019 11:29:13 AM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `doctorspecilization`
--

CREATE TABLE `doctorspecilization` (
  `id` int(11) NOT NULL,
  `specilization` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorspecilization`
--

INSERT INTO `doctorspecilization` (`id`, `specilization`, `creationDate`, `updationDate`) VALUES
(9, 'Detoxification Program Type 1', '2016-12-28 07:37:39', '2019-11-23 05:02:40'),
(10, 'Detoxification Program Type 2', '2017-01-07 08:07:53', '2019-11-23 05:03:07'),
(13, 'Counseling', '2019-11-22 00:20:48', '2019-11-23 05:04:16'),
(14, 'Group Therapy', '2019-11-22 00:22:42', '2019-11-23 05:04:48'),
(15, 'Narcotics meeting', '2019-11-22 00:25:21', '2019-11-23 05:05:35');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactus`
--

CREATE TABLE `tblcontactus` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contactno` bigint(12) DEFAULT NULL,
  `message` mediumtext DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `AdminRemark` mediumtext DEFAULT NULL,
  `LastupdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `IsRead` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontactus`
--

INSERT INTO `tblcontactus` (`id`, `fullname`, `email`, `contactno`, `message`, `PostingDate`, `AdminRemark`, `LastupdationDate`, `IsRead`) VALUES
(8, 'Jayalakshmi M', 'jayanaik9090@gmail.com', 6362314293, ' jhgfd', '2019-11-30 04:05:44', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblmedicalhistory`
--

CREATE TABLE `tblmedicalhistory` (
  `ID` int(10) NOT NULL,
  `PatientID` int(10) DEFAULT NULL,
  `BloodPressure` varchar(200) DEFAULT NULL,
  `BloodSugar` varchar(200) NOT NULL,
  `Weight` varchar(100) DEFAULT NULL,
  `Temperature` varchar(200) DEFAULT NULL,
  `MedicalPres` mediumtext DEFAULT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblmedicalhistory`
--

INSERT INTO `tblmedicalhistory` (`ID`, `PatientID`, `BloodPressure`, `BloodSugar`, `Weight`, `Temperature`, `MedicalPres`, `CreationDate`) VALUES
(14, 19, '2', '-', '23', '-', '1', '2019-11-29 18:36:13'),
(15, 20, '-', '-', '45', '-', '3', '2019-11-30 01:18:51');

-- --------------------------------------------------------

--
-- Table structure for table `tblpatient`
--

CREATE TABLE `tblpatient` (
  `ID` int(10) NOT NULL,
  `Docid` int(10) DEFAULT NULL,
  `PatientName` varchar(200) DEFAULT NULL,
  `PatientContno` bigint(10) DEFAULT NULL,
  `PatientEmail` varchar(200) DEFAULT NULL,
  `PatientGender` varchar(50) DEFAULT NULL,
  `PatientAdd` mediumtext DEFAULT NULL,
  `PatientAge` int(10) DEFAULT NULL,
  `PatientMedhis` mediumtext DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpatient`
--

INSERT INTO `tblpatient` (`ID`, `Docid`, `PatientName`, `PatientContno`, `PatientEmail`, `PatientGender`, `PatientAdd`, `PatientAge`, `PatientMedhis`, `CreationDate`, `UpdationDate`) VALUES
(19, 22, 'Priya', 8123465789, 'patpriya@gmail.com', 'female', 'Bangalore', 21, 'nothing', '2019-11-29 18:33:39', NULL),
(20, 27, 'Dhanya', 8123465789, 'patdhanya@gmail.com', 'female', 'karkal', 20, '-', '2019-11-30 01:18:13', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT current_timestamp(),
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(74, 19, 'patpriya@gmail.com', 0x3a3a3100000000000000000000000000, '2019-11-29 18:28:21', NULL, 1),
(75, 16, 'patdhanya@gmail.com', 0x3a3a3100000000000000000000000000, '2019-11-30 01:16:14', NULL, 1),
(76, 16, 'patdhanya@gmail.com', 0x3a3a3100000000000000000000000000, '2019-11-30 01:20:05', '30-11-2019 06:50:20 AM', 1),
(77, 19, 'patpriya@gmail.com', 0x3a3a3100000000000000000000000000, '2019-11-30 01:20:35', NULL, 1),
(78, 19, 'patpriya@gmail.com', 0x3a3a3100000000000000000000000000, '2019-11-30 05:59:29', '30-11-2019 11:35:23 AM', 1),
(79, 19, 'patpriya@gmail.com', 0x3a3a3100000000000000000000000000, '2019-11-30 07:22:24', NULL, 1),
(80, 19, 'patpriya@gmail.com', 0x3a3a3100000000000000000000000000, '2019-12-02 04:14:16', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `address` longtext DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `regDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullName`, `address`, `city`, `gender`, `email`, `password`, `regDate`, `updationDate`) VALUES
(16, 'Dhanya', 'karkal', 'Manglore', 'female', 'patdhanya@gmail.com', '53c373ef0c44ae25e4bef850722662da', '2019-11-29 17:47:12', NULL),
(17, 'Kanaka', 'sagar', 'sagar', 'female', 'patkanaka@gmail.com', 'b5ea2b514de95398cf17f45b7d48d893', '2019-11-29 17:49:01', NULL),
(18, 'Apoorva', 'Bangalore', 'Bangalore', 'female', 'patappu@gmail.com', '8816f821293fa182619d517c58f6f552', '2019-11-29 17:51:36', NULL),
(19, 'Priya', 'Murdeshwar', 'bhatkal', 'female', 'patpriya@gmail.com', 'cb35f9bf2824037ffee1b35812305a59', '2019-11-29 18:28:06', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorslog`
--
ALTER TABLE `doctorslog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorspecilization`
--
ALTER TABLE `doctorspecilization`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactus`
--
ALTER TABLE `tblcontactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblmedicalhistory`
--
ALTER TABLE `tblmedicalhistory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblpatient`
--
ALTER TABLE `tblpatient`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `doctorslog`
--
ALTER TABLE `doctorslog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `doctorspecilization`
--
ALTER TABLE `doctorspecilization`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tblcontactus`
--
ALTER TABLE `tblcontactus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tblmedicalhistory`
--
ALTER TABLE `tblmedicalhistory`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tblpatient`
--
ALTER TABLE `tblpatient`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
